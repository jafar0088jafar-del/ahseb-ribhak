const $ = id => document.getElementById(id);
const fmt = n => new Intl.NumberFormat('ar-IQ').format(Math.round(n));

function calculate(){
  const buy = Number($('buy').value);
  const sell = Number($('sell').value);
  const qty = Number($('qty').value);
  if(!buy || !sell || !qty || buy < 0 || sell < 0 || qty < 1){
    alert('رجاءً أدخل القيم بشكل صحيح.');
    return;
  }
  const cost = buy * qty;
  const revenue = sell * qty;
  const profit = revenue - cost;
  const margin = cost ? (profit / cost) * 100 : 0;

  $('cost').textContent = fmt(cost);
  $('revenue').textContent = fmt(revenue);
  $('profit').textContent = fmt(profit);
  $('margin').textContent = margin.toFixed(1) + '%';
  $('results').classList.remove('hidden');

  const data = {buy,sell,qty,cost,revenue,profit,margin, savedAt:new Date().toLocaleString('ar-IQ')};
  localStorage.setItem('ahseb_ribhak_last', JSON.stringify(data));
  showSaved(data);
}

function showSaved(data){
  if(!data){ $('saved').textContent='ماكو عملية محفوظة حالياً.'; return; }
  $('saved').textContent = `آخر عملية: شراء ${fmt(data.buy)} د.ع، بيع ${fmt(data.sell)} د.ع، كمية ${fmt(data.qty)} — الربح ${fmt(data.profit)} د.ع`;
}

$('calc').addEventListener('click', calculate);
$('clear').addEventListener('click', ()=>{
  localStorage.removeItem('ahseb_ribhak_last');
  showSaved(null);
});
document.addEventListener('keydown', e=>{if(e.key==='Enter') calculate();});

try { showSaved(JSON.parse(localStorage.getItem('ahseb_ribhak_last'))); } catch(e) { showSaved(null); }